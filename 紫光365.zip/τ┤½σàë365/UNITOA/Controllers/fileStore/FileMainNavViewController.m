//
//  FileMainNavViewController.m
//  UNITOA
//
//  Created by qidi on 14-11-12.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "FileMainNavViewController.h"
#import "companyMemberlistViewController.h"
@interface FileMainNavViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView  *_tableView;
    NSArray *_NAVArray;
}
@property(nonatomic,strong)UITableView  *tableView;
@property(nonatomic,strong)NSArray  *NAVArray;
@end
@implementation FileMainNavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    if (IOS7_LATER) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.aTitle = LOCALIZATION(@"filestore");
    self.NAVArray = @[LOCALIZATION(@"company_filestore"),LOCALIZATION(@"private_filestore"),LOCALIZATION(@"locao_filestore")];
    [self creaTable];
}
- (void)creaTable{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 64) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [ZSTool setExtraCellLineHidden:self.tableView];
    [self.view addSubview:self.tableView];
}
#pragma mark -------------UITableViewDelegate----------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.NAVArray count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellName = @"Fcell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellName];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName];
    }
    cell.textLabel.text = self.NAVArray[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        companyMemberlistViewController *companyVC = [[companyMemberlistViewController alloc]init];
        [self.navigationController pushViewController:companyVC animated:YES];
    }
    else if (indexPath.row == 1){
        
    }
    else if (indexPath .row == 2){
        
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
