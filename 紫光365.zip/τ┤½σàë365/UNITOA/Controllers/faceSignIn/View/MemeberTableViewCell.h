//
//  MemeberTableViewCell.h
//  UNITOA
//
//  Created by qidi on 14-11-11.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MemeberTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *memeberNameLable;
@property (weak, nonatomic) IBOutlet UILabel *addressLable;
@property (weak, nonatomic) IBOutlet UILabel *signDataLable;
@end
