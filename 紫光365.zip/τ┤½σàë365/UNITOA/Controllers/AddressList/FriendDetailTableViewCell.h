//
//  FriendDetailTableViewCell.h
//  UNITOA
//
//  Created by qidi on 14-6-26.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendDetailTableViewCell : UITableViewCell

@end
