//
//  BaseCalendarGridView.h
//  ZHJCalendar
//
//  Created by huajian zhou on 12-4-12.
//  Copyright (c) 2012年 itotemstudio. All rights reserved.
//

#import "ITTCalendarGridView.h"

@interface ITTBaseCalendarGridView : ITTCalendarGridView

@end
