//
//  GroupsViewController.h
//  VColleagueChat
//
//  Created by lqy on 4/22/14.
//  Copyright (c) 2014 laimark.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupsViewController : UIViewController

@end
