//
//  ChineseString.m
//  ChineseSort
//
//  Created by Bill on 12-8-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ChineseString.h"

@implementation ChineseString

@synthesize string = _string;
@synthesize pinYin = _pinYin;

- (id)init {
    if (self = [super init]) {
        
    }
    
    return self;
}


@end
