//
//  UncaughtExceptionHandler.h
//  UNITOA
//
//  Created by qidi on 14-7-30.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UncaughtExceptionHandler : NSObject
{
    
    BOOL dismissed;
    
}
void InstallUncaughtExceptionHandler();
@end
