//
//  AppInPhone.h
//  UNITOA
//
//  Created by qidi on 14-7-1.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppInPhone : NSObject
+ (void)telInPhone:(NSString *)urlStr;
+ (void)smsInPhone:(NSString *)urlStr;
+ (void)mailInPhone:(NSString *)urlStr;
@end
