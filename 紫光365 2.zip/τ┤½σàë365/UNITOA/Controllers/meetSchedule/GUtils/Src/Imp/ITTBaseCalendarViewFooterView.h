//
//  BaseCalendarViewFooterView.h
//  ZHJCalendar
//
//  Created by huajian zhou on 12-4-13.
//  Copyright (c) 2012年 itotemstudio. All rights reserved.
//

#import "ITTCalendarViewFooterView.h"

@interface ITTBaseCalendarViewFooterView : ITTCalendarViewFooterView
{

}
@end
