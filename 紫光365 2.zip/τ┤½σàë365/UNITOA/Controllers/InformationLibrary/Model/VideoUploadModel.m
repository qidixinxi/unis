//
//  VideoUploadModel.m
//  GUKE
//
//  Created by soulnear on 14-10-4.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "VideoUploadModel.h"

@implementation VideoUploadModel

@end
