//
//  SolveReasonCell.m
//  UNITOA
//
//  Created by ianMac on 14-9-16.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "SolveReasonCell.h"

@implementation SolveReasonCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
