//
//  companyMemberlistViewController.h
//  UNITOA
//
//  Created by qidi on 14-11-13.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SNViewController.h"
@interface companyMemberlistViewController : SNViewController
@property (nonatomic, retain) NSMutableArray *sortedArrForArrays;
@property (nonatomic, retain) NSMutableArray *sectionHeadsKeys;
@end
