//
//  SignInTableViewCell.h
//  UNITOA
//
//  Created by qidi on 14-11-7.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignInTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLable;
@property (weak, nonatomic) IBOutlet UILabel *detailNameLable;
@property (weak, nonatomic) IBOutlet UIButton *signBtn;
@end
