//
//  signListTableViewCell.h
//  UNITOA
//
//  Created by qidi on 14-11-11.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface signListTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *reasonLable;
@property (weak, nonatomic) IBOutlet UILabel *expireDate;
@end
