//
//  SinIn_NewModel.m
//  UNITOA
//
//  Created by qidi on 14-11-10.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "SinIn_NewModel.h"

@interface SinIn_NewModel ()

@end

@implementation SinIn_NewModel

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
