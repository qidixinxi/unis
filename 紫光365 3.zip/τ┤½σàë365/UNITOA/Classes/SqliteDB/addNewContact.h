//
//  addNewContact.h
//  UNITOA
//
//  Created by qidi on 14-8-26.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface addNewContact : NSObject
+ (void)addUserContact:(NSString *)contactId;
@end
