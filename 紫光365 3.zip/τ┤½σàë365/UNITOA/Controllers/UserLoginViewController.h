//
//  UserLoginViewController.h
//  leliao
//
//  Created by qidi on 14-6-23.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckBox.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
@interface UserLoginViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate,CheckBoxDelegate,MBProgressHUDDelegate>
@end
