//
//  UserCenter.h
//  VColleagueChat
//
//  Created by Ming Zhang on 14-5-25.
//  Copyright (c) 2014年 laimark.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserCenter : NSObject
@property (nonatomic) BOOL uploadDeviceToken;

+ (UserCenter *)sharedClientCenter;
- (void)uploadDeviceToken:(NSData *)data;
@end
