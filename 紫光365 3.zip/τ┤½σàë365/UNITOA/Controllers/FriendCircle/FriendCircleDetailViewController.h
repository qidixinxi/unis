//
//  FriendCircleDetailViewController.h
//  UNITOA
//
//  Created by ianMac on 14-7-28.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "HPGrowingTextView.h"
#import "UserArticleList.h"
#import "UserIfo.h"
//#import "RTLabel.h"
#import "MyLabel.h"


@interface FriendCircleDetailViewController : UITableViewController<UITableViewDataSource,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,HPGrowingTextViewDelegate,MBProgressHUDDelegate,MyLabelDelegate>

- (instancetype)initWithModel:(NSString *)userId;
@end
