//
//  UserContactViewController.h
//  UNITOA
//
//  Created by qidi on 14-6-30.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
@interface UserContactViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,MBProgressHUDDelegate,UIScrollViewDelegate>
@property(nonatomic, assign)NSUInteger index;
@end
