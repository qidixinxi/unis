//
//  UserListModel.m
//  UNITOA
//
//  Created by qidi on 14-11-11.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "UserListModel.h"

@implementation UserListModel

@end
