//
//  InformationDetailModel.m
//  GUKE
//
//  Created by ianMac on 14-9-25.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "InformationDetailModel.h"

@implementation InformationDetailModel

@end
