//
//  VideoUploadModel.h
//  GUKE
//ss
//  Created by soulnear on 14-10-4.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoUploadModel : NSObject
@property(nonatomic,strong)NSString * fileName;
@property(nonatomic,strong)NSData * fileData;
@property(nonatomic,strong)NSString * fileSize;
@property(nonatomic,strong)NSString * filePath;

@end









