//
//  InformationModel.m
//  GUKE
//
//  Created by ianMac on 14-9-24.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "InformationModel.h"

@implementation InformationModel

@end
