//
//  AboutProduceViewController.h
//  UNITOA
//
//  Created by qidi on 14-9-16.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RTLabel.h"
@interface AboutProduceViewController : UIViewController<RTLabelDelegate>

@end
